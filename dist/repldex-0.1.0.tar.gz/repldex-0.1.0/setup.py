# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['repldex', 'repldex.backend', 'repldex.config', 'repldex.discordbot']

package_data = \
{'': ['*'],
 'repldex.backend': ['static/*',
                     'static/formats/*',
                     'templates/*',
                     'templates/admin/*'],
 'repldex.config': ['other/*']}

install_requires = \
['aiodns>=2.0.0,<3.0.0',
 'aiohttp>=3.6.2,<4.0.0',
 'beautifulsoup4>=4.9.3,<5.0.0',
 'cchardet>=2.1.7,<3.0.0',
 'discord.py>=1.6.0,<2.0.0',
 'jellyfish>=0.8.2,<0.9.0',
 'jinja2>=2.11.2,<3.0.0',
 'motor>=2.1.0,<3.0.0',
 'pymongo[srv]>=3.11',
 'timeago>=1.0.14,<2.0.0']

setup_kwargs = {
    'name': 'repldex',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'mat',
    'author_email': 'replit@matdoes.dev',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
